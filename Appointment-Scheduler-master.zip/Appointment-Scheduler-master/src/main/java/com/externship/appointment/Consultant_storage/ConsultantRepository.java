package com.externship.appointment.Consultant_storage;
import org.springframework.data.repository.CrudRepository;

public interface ConsultantRepository extends CrudRepository<Consultant,String>{
	//List<Consultant> findAll();
	//Optional<Consultant> findById(String Id);

	
}
