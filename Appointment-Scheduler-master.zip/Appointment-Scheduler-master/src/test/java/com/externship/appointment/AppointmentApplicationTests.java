package com.externship.appointment;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.servlet.ModelAndView;

import com.externship.appointment.Appointment_storage.Appointment;
import com.externship.appointment.Appointment_storage.AppointmentRepository;
import com.externship.appointment.Consultant_storage.Consultant;
import com.externship.appointment.Consultant_storage.ConsultantRepository;
import com.externship.appointment.Person_storage.Person;
import com.externship.appointment.Person_storage.PersonRepository;

public class AppointmentApplicationTests {

    private ControllerClass controller;

    private PersonRepository personRepository;
    private ConsultantRepository consultantRepository;
    private AppointmentRepository appointmentRepository;

    @BeforeEach
    public void setup() {
        personRepository = mock(PersonRepository.class);
        consultantRepository = mock(ConsultantRepository.class);
        appointmentRepository = mock(AppointmentRepository.class);
        
        controller = new ControllerClass();
        controller.personRepo = personRepository;
        controller.docRepo = consultantRepository;
        controller.appRepo = appointmentRepository;
    }

    @Test
    public void testAuthenticateValidPerson() {
        Person person = new Person();
        person.setEmail("test@example.com");
        person.setPassword("password");

        HttpSession session = mock(HttpSession.class);
        when(personRepository.existsById(person.getEmail())).thenReturn(true);
        when(personRepository.findById(person.getEmail())).thenReturn(java.util.Optional.of(person));
        String mav = controller.authenticate(person, session);

        verify(session).setAttribute("person", person.getEmail());
        // You can add more assertions here to verify the behavior of the method.
    }

    @Test
    public void testAuthenticateInvalidPerson() {
        Person person = new Person();
        person.setEmail("test@example.com");
        person.setPassword("wrong_password");

        HttpSession session = mock(HttpSession.class);
        when(personRepository.existsById(person.getEmail())).thenReturn(true);
        when(personRepository.findById(person.getEmail())).thenReturn(java.util.Optional.of(person));
        String mav = controller.authenticate(person, session);

        // You can add assertions here to verify the behavior when authentication fails.
    }

    @Test
    public void testSubmitted() {
        Appointment appointment = new Appointment();
        appointment.setEmail("test@example.com");

        String mav = controller.submitted(appointment);

        // You can add assertions here to verify the behavior of the method.
    }

    // Add more test methods for other controller methods as needed.
}
