# Consultant-Appointment-Scheduler
A springboot based project that provides and easy to use web application which enables Job Seekers to schedule an appointment with a Consultant of their choice.

### Functionalities
* Job Seeker Regitrsation
* Job Seeker Login
* Consultant Registration
* Consultant Login
* Job Seeker can book, view and cancel appointments
* Consultant can view and cancel appointments

### Tools and Technologies
- Spring Boot
- MVC Architecture
- Thymeleaf templating
- JPA
- H2 inmemory database
- CRUD operations

### Requirements
- Maven
- Java


